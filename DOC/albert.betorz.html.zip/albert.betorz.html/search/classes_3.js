var searchData=
[
  ['missatge_47',['Missatge',['../class_missatge.html',1,'']]]
];
