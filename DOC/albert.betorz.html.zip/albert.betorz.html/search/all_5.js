var searchData=
[
  ['left_30',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llegir_31',['llegir',['../class_alfabet.html#a9780dd148dd1378880617bfa1a198024',1,'Alfabet::llegir()'],['../class_cjt__alfabets.html#aad02802baf9bfee2daaca8aa841ff7aa',1,'Cjt_alfabets::llegir()'],['../class_cjt__missatges.html#a46d4d4f9a2fef92b2f8299b910405004',1,'Cjt_missatges::llegir()'],['../class_missatge.html#a23c9bb5790be9a60641abc8974c7a088',1,'Missatge::llegir()']]]
];
