var searchData=
[
  ['missatge_2ehh_52',['Missatge.hh',['../_missatge_8hh.html',1,'']]]
];
