var searchData=
[
  ['decodificar_5fmissatge_5fperm_22',['decodificar_missatge_perm',['../class_missatge.html#a016268db3c4d178bcc8142252da74344',1,'Missatge']]],
  ['decodificar_5fmissatge_5fsust_23',['decodificar_missatge_sust',['../class_missatge.html#add2bb45dafbd9cdb1d7cba0657ea6b48',1,'Missatge']]]
];
