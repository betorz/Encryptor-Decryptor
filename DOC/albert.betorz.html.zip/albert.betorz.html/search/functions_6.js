var searchData=
[
  ['main_81',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mida_82',['mida',['../class_cjt__alfabets.html#af081d3fa355b01698d97a87909010af3',1,'Cjt_alfabets::mida()'],['../class_cjt__missatges.html#acde290ab45f8a373825441db1997ce3f',1,'Cjt_missatges::mida()']]],
  ['missatge_83',['Missatge',['../class_missatge.html#a0bd83901985857c90f9572d39dc12c2b',1,'Missatge::Missatge()'],['../class_missatge.html#a149c2b36aacad6fc2ba95182e2a4b56d',1,'Missatge::Missatge(string id, string alf_id)']]],
  ['modificar_5falfabet_84',['modificar_alfabet',['../class_cjt__alfabets.html#a0c1fdc5d9b89466636d5585824f83672',1,'Cjt_alfabets']]],
  ['modificar_5fmissatge_85',['modificar_missatge',['../class_cjt__missatges.html#a5214702803e08bf4ff7220efe1616a4d',1,'Cjt_missatges']]]
];
