var searchData=
[
  ['cjt_5falfabets_45',['Cjt_alfabets',['../class_cjt__alfabets.html',1,'']]],
  ['cjt_5fmissatges_46',['Cjt_missatges',['../class_cjt__missatges.html',1,'']]]
];
