var searchData=
[
  ['matriu_88',['Matriu',['../_alfabet_8hh.html#a356de7393c8771fc61c439ab1d85458a',1,'Matriu():&#160;Alfabet.hh'],['../_cjt__alfabets_8hh.html#a356de7393c8771fc61c439ab1d85458a',1,'Matriu():&#160;Cjt_alfabets.hh']]]
];
