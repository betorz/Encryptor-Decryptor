var searchData=
[
  ['cjt_5falfabets_8',['Cjt_alfabets',['../class_cjt__alfabets.html',1,'Cjt_alfabets'],['../class_cjt__alfabets.html#af454403a637536adf799567b58daa7b9',1,'Cjt_alfabets::Cjt_alfabets()']]],
  ['cjt_5falfabets_2ehh_9',['Cjt_alfabets.hh',['../_cjt__alfabets_8hh.html',1,'']]],
  ['cjt_5fmissatges_10',['Cjt_missatges',['../class_cjt__missatges.html',1,'Cjt_missatges'],['../class_cjt__missatges.html#a80b3582ce7b1f30548b5ea4c54420ae8',1,'Cjt_missatges::Cjt_missatges()']]],
  ['cjt_5fmissatges_2ehh_11',['Cjt_missatges.hh',['../_cjt__missatges_8hh.html',1,'']]],
  ['codificar_5fmissatge_5fperm_12',['codificar_missatge_perm',['../class_missatge.html#a26c387b6c1396a82c1ade055a2240b2a',1,'Missatge']]],
  ['codificar_5fmissatge_5fsust_13',['codificar_missatge_sust',['../class_missatge.html#a28c7bab5e13b2610da83dec917631075',1,'Missatge']]],
  ['consultar_5falfabet_14',['consultar_alfabet',['../class_cjt__alfabets.html#ac4ce1113de881810848e2baa33caaf0e',1,'Cjt_alfabets']]],
  ['consultar_5fcaracters_15',['consultar_caracters',['../class_alfabet.html#a00746b692e02b6c498af3278f54f8eae',1,'Alfabet']]],
  ['consultar_5fid_16',['consultar_id',['../class_alfabet.html#a74b4b237a22ef0d36c45f5edadb8b27d',1,'Alfabet::consultar_id()'],['../class_missatge.html#ac80bbf502783ce46a021907a266341f0',1,'Missatge::consultar_id()']]],
  ['consultar_5fmissatge_17',['consultar_missatge',['../class_cjt__missatges.html#a4c42e9017377320a76a1135706a60c5d',1,'Cjt_missatges']]],
  ['consultar_5fmissatge_5fcodificat_18',['consultar_missatge_codificat',['../class_missatge.html#a843641f8f333cef3e8ae8197a9096068',1,'Missatge']]],
  ['consultar_5fmissatge_5foriginal_19',['consultar_missatge_original',['../class_missatge.html#a11b835cb8812d995ab809babbd082687',1,'Missatge']]],
  ['crear_5farbre_5forig_20',['crear_arbre_orig',['../class_missatge.html#a6b671c2ca87b0a1eeb4bc9e6f14e3563',1,'Missatge']]],
  ['crear_5fmatriu_21',['crear_matriu',['../class_alfabet.html#a81324de6f2b42473e837936e593a09d8',1,'Alfabet']]]
];
