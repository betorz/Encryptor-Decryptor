var searchData=
[
  ['afegir_5falfabet_0',['afegir_alfabet',['../class_cjt__alfabets.html#aad37b4c2a8dda36fa3e66822af1a4cf7',1,'Cjt_alfabets']]],
  ['afegir_5fclau_1',['afegir_clau',['../class_missatge.html#a689442b0fa6682f2aef0cd22b52ee2ab',1,'Missatge']]],
  ['afegir_5fmissatge_2',['afegir_missatge',['../class_cjt__missatges.html#a5384f9f2a5ebdaeab0930592904265c7',1,'Cjt_missatges']]],
  ['alfabet_3',['Alfabet',['../class_alfabet.html',1,'Alfabet'],['../class_alfabet.html#acc775d84db07dab4123a990cea8970ec',1,'Alfabet::Alfabet()'],['../class_alfabet.html#a1f8bf45f0e86358305478529467100cc',1,'Alfabet::Alfabet(string id)']]],
  ['alfabet_2ehh_4',['Alfabet.hh',['../_alfabet_8hh.html',1,'']]]
];
